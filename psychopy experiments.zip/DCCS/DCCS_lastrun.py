﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.2.5),
    on 三月 27, 2023, at 17:05
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.2.5'
expName = 'DCCS3'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'session': '001',
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='D:\\杭幼师相关\\LITY LAB\\体感游戏\\执行功能测量\\psychopy\\卡片分类DCCS\\DCCS_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1280, 800], fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color='white', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# --- Initialize components for Routine "instruct1" ---
instruction1image = visual.ImageStim(
    win=win,
    name='instruction1image', 
    image='1_1.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instruction1key = keyboard.Keyboard()

# --- Initialize components for Routine "fixation" ---
text = visual.TextStim(win=win, name='text',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "block1" ---
block1image = visual.ImageStim(
    win=win,
    name='block1image', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
block1key_resp = keyboard.Keyboard()

# --- Initialize components for Routine "instruct2" ---
instruction2image = visual.ImageStim(
    win=win,
    name='instruction2image', 
    image='1_2.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instruction2ke = keyboard.Keyboard()

# --- Initialize components for Routine "fixation" ---
text = visual.TextStim(win=win, name='text',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "block2" ---
block2image = visual.ImageStim(
    win=win,
    name='block2image', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
block2key_resp = keyboard.Keyboard()

# --- Initialize components for Routine "instruct3" ---
instruction3image = visual.ImageStim(
    win=win,
    name='instruction3image', 
    image='1_3.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instruction3key = keyboard.Keyboard()

# --- Initialize components for Routine "fixation" ---
text = visual.TextStim(win=win, name='text',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "block3" ---
block3image = visual.ImageStim(
    win=win,
    name='block3image', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
block3key = keyboard.Keyboard()

# --- Initialize components for Routine "instruct4" ---
instruction4image = visual.ImageStim(
    win=win,
    name='instruction4image', 
    image='2_1.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instruction4key = keyboard.Keyboard()

# --- Initialize components for Routine "fixation" ---
text = visual.TextStim(win=win, name='text',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "block4" ---
block4image = visual.ImageStim(
    win=win,
    name='block4image', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
block4key = keyboard.Keyboard()

# --- Initialize components for Routine "instruct5" ---
instruction5image = visual.ImageStim(
    win=win,
    name='instruction5image', 
    image='2_2.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instruction5key = keyboard.Keyboard()

# --- Initialize components for Routine "fixation" ---
text = visual.TextStim(win=win, name='text',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "block5" ---
block5image = visual.ImageStim(
    win=win,
    name='block5image', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
block5key = keyboard.Keyboard()

# --- Initialize components for Routine "instruct6" ---
instruction6image = visual.ImageStim(
    win=win,
    name='instruction6image', 
    image='2_3.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instruction6key = keyboard.Keyboard()

# --- Initialize components for Routine "fixation" ---
text = visual.TextStim(win=win, name='text',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "block6" ---
block6image = visual.ImageStim(
    win=win,
    name='block6image', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
block6key = keyboard.Keyboard()

# --- Initialize components for Routine "END" ---
quit = visual.ImageStim(
    win=win,
    name='quit', 
    image='完成啦.bmp', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
quitkey = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# --- Prepare to start Routine "instruct1" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instruction1key.keys = []
instruction1key.rt = []
_instruction1key_allKeys = []
# keep track of which components have finished
instruct1Components = [instruction1image, instruction1key]
for thisComponent in instruct1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instruct1" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruction1image* updates
    if instruction1image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction1image.frameNStart = frameN  # exact frame index
        instruction1image.tStart = t  # local t and not account for scr refresh
        instruction1image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction1image, 'tStartRefresh')  # time at next scr refresh
        instruction1image.setAutoDraw(True)
    
    # *instruction1key* updates
    if instruction1key.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction1key.frameNStart = frameN  # exact frame index
        instruction1key.tStart = t  # local t and not account for scr refresh
        instruction1key.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction1key, 'tStartRefresh')  # time at next scr refresh
        instruction1key.status = STARTED
        # keyboard checking is just starting
        instruction1key.clock.reset()  # now t=0
    if instruction1key.status == STARTED:
        theseKeys = instruction1key.getKeys(keyList=['space'], waitRelease=False)
        _instruction1key_allKeys.extend(theseKeys)
        if len(_instruction1key_allKeys):
            instruction1key.keys = _instruction1key_allKeys[-1].name  # just the last key pressed
            instruction1key.rt = _instruction1key_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instruct1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instruct1" ---
for thisComponent in instruct1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instruct1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=3.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('block1.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "fixation" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # keep track of which components have finished
    fixationComponents = [text]
    for thisComponent in fixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "fixation" ---
    while continueRoutine and routineTimer.getTime() < 0.6:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 0.6-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "fixation" ---
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-0.600000)
    
    # --- Prepare to start Routine "block1" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    block1image.setImage(pic1)
    block1key_resp.keys = []
    block1key_resp.rt = []
    _block1key_resp_allKeys = []
    # keep track of which components have finished
    block1Components = [block1image, block1key_resp]
    for thisComponent in block1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "block1" ---
    while continueRoutine and routineTimer.getTime() < 1.7:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block1image* updates
        if block1image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block1image.frameNStart = frameN  # exact frame index
            block1image.tStart = t  # local t and not account for scr refresh
            block1image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block1image, 'tStartRefresh')  # time at next scr refresh
            block1image.setAutoDraw(True)
        if block1image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block1image.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block1image.tStop = t  # not accounting for scr refresh
                block1image.frameNStop = frameN  # exact frame index
                block1image.setAutoDraw(False)
        
        # *block1key_resp* updates
        waitOnFlip = False
        if block1key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block1key_resp.frameNStart = frameN  # exact frame index
            block1key_resp.tStart = t  # local t and not account for scr refresh
            block1key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block1key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'block1key_resp.started')
            block1key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(block1key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(block1key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if block1key_resp.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block1key_resp.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block1key_resp.tStop = t  # not accounting for scr refresh
                block1key_resp.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'block1key_resp.stopped')
                block1key_resp.status = FINISHED
        if block1key_resp.status == STARTED and not waitOnFlip:
            theseKeys = block1key_resp.getKeys(keyList=['f','j'], waitRelease=False)
            _block1key_resp_allKeys.extend(theseKeys)
            if len(_block1key_resp_allKeys):
                block1key_resp.keys = _block1key_resp_allKeys[-1].name  # just the last key pressed
                block1key_resp.rt = _block1key_resp_allKeys[-1].rt
                # was this correct?
                if (block1key_resp.keys == str(answer1)) or (block1key_resp.keys == answer1):
                    block1key_resp.corr = 1
                else:
                    block1key_resp.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in block1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "block1" ---
    for thisComponent in block1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if block1key_resp.keys in ['', [], None]:  # No response was made
        block1key_resp.keys = None
        # was no response the correct answer?!
        if str(answer1).lower() == 'none':
           block1key_resp.corr = 1;  # correct non-response
        else:
           block1key_resp.corr = 0;  # failed to respond (incorrectly)
    # store data for trials (TrialHandler)
    trials.addData('block1key_resp.keys',block1key_resp.keys)
    trials.addData('block1key_resp.corr', block1key_resp.corr)
    if block1key_resp.keys != None:  # we had a response
        trials.addData('block1key_resp.rt', block1key_resp.rt)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-1.700000)
    thisExp.nextEntry()
    
# completed 3.0 repeats of 'trials'


# --- Prepare to start Routine "instruct2" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instruction2ke.keys = []
instruction2ke.rt = []
_instruction2ke_allKeys = []
# keep track of which components have finished
instruct2Components = [instruction2image, instruction2ke]
for thisComponent in instruct2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instruct2" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruction2image* updates
    if instruction2image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction2image.frameNStart = frameN  # exact frame index
        instruction2image.tStart = t  # local t and not account for scr refresh
        instruction2image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction2image, 'tStartRefresh')  # time at next scr refresh
        instruction2image.setAutoDraw(True)
    
    # *instruction2ke* updates
    if instruction2ke.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction2ke.frameNStart = frameN  # exact frame index
        instruction2ke.tStart = t  # local t and not account for scr refresh
        instruction2ke.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction2ke, 'tStartRefresh')  # time at next scr refresh
        instruction2ke.status = STARTED
        # keyboard checking is just starting
        instruction2ke.clock.reset()  # now t=0
    if instruction2ke.status == STARTED:
        theseKeys = instruction2ke.getKeys(keyList=['space'], waitRelease=False)
        _instruction2ke_allKeys.extend(theseKeys)
        if len(_instruction2ke_allKeys):
            instruction2ke.keys = _instruction2ke_allKeys[-1].name  # just the last key pressed
            instruction2ke.rt = _instruction2ke_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instruct2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instruct2" ---
for thisComponent in instruct2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instruct2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials_2 = data.TrialHandler(nReps=3.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('block2.xlsx'),
    seed=None, name='trials_2')
thisExp.addLoop(trials_2)  # add the loop to the experiment
thisTrial_2 = trials_2.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
if thisTrial_2 != None:
    for paramName in thisTrial_2:
        exec('{} = thisTrial_2[paramName]'.format(paramName))

for thisTrial_2 in trials_2:
    currentLoop = trials_2
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_2.rgb)
    if thisTrial_2 != None:
        for paramName in thisTrial_2:
            exec('{} = thisTrial_2[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "fixation" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # keep track of which components have finished
    fixationComponents = [text]
    for thisComponent in fixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "fixation" ---
    while continueRoutine and routineTimer.getTime() < 0.6:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 0.6-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "fixation" ---
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-0.600000)
    
    # --- Prepare to start Routine "block2" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    block2image.setImage(pic2)
    block2key_resp.keys = []
    block2key_resp.rt = []
    _block2key_resp_allKeys = []
    # keep track of which components have finished
    block2Components = [block2image, block2key_resp]
    for thisComponent in block2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "block2" ---
    while continueRoutine and routineTimer.getTime() < 1.7:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block2image* updates
        if block2image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block2image.frameNStart = frameN  # exact frame index
            block2image.tStart = t  # local t and not account for scr refresh
            block2image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block2image, 'tStartRefresh')  # time at next scr refresh
            block2image.setAutoDraw(True)
        if block2image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block2image.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block2image.tStop = t  # not accounting for scr refresh
                block2image.frameNStop = frameN  # exact frame index
                block2image.setAutoDraw(False)
        
        # *block2key_resp* updates
        waitOnFlip = False
        if block2key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block2key_resp.frameNStart = frameN  # exact frame index
            block2key_resp.tStart = t  # local t and not account for scr refresh
            block2key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block2key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'block2key_resp.started')
            block2key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(block2key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(block2key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if block2key_resp.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block2key_resp.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block2key_resp.tStop = t  # not accounting for scr refresh
                block2key_resp.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'block2key_resp.stopped')
                block2key_resp.status = FINISHED
        if block2key_resp.status == STARTED and not waitOnFlip:
            theseKeys = block2key_resp.getKeys(keyList=['f','j'], waitRelease=False)
            _block2key_resp_allKeys.extend(theseKeys)
            if len(_block2key_resp_allKeys):
                block2key_resp.keys = _block2key_resp_allKeys[-1].name  # just the last key pressed
                block2key_resp.rt = _block2key_resp_allKeys[-1].rt
                # was this correct?
                if (block2key_resp.keys == str(answer2)) or (block2key_resp.keys == answer2):
                    block2key_resp.corr = 1
                else:
                    block2key_resp.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in block2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "block2" ---
    for thisComponent in block2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if block2key_resp.keys in ['', [], None]:  # No response was made
        block2key_resp.keys = None
        # was no response the correct answer?!
        if str(answer2).lower() == 'none':
           block2key_resp.corr = 1;  # correct non-response
        else:
           block2key_resp.corr = 0;  # failed to respond (incorrectly)
    # store data for trials_2 (TrialHandler)
    trials_2.addData('block2key_resp.keys',block2key_resp.keys)
    trials_2.addData('block2key_resp.corr', block2key_resp.corr)
    if block2key_resp.keys != None:  # we had a response
        trials_2.addData('block2key_resp.rt', block2key_resp.rt)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-1.700000)
    thisExp.nextEntry()
    
# completed 3.0 repeats of 'trials_2'


# --- Prepare to start Routine "instruct3" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instruction3key.keys = []
instruction3key.rt = []
_instruction3key_allKeys = []
# keep track of which components have finished
instruct3Components = [instruction3image, instruction3key]
for thisComponent in instruct3Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instruct3" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruction3image* updates
    if instruction3image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction3image.frameNStart = frameN  # exact frame index
        instruction3image.tStart = t  # local t and not account for scr refresh
        instruction3image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction3image, 'tStartRefresh')  # time at next scr refresh
        instruction3image.setAutoDraw(True)
    
    # *instruction3key* updates
    if instruction3key.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction3key.frameNStart = frameN  # exact frame index
        instruction3key.tStart = t  # local t and not account for scr refresh
        instruction3key.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction3key, 'tStartRefresh')  # time at next scr refresh
        instruction3key.status = STARTED
        # keyboard checking is just starting
        instruction3key.clock.reset()  # now t=0
    if instruction3key.status == STARTED:
        theseKeys = instruction3key.getKeys(keyList=['space'], waitRelease=False)
        _instruction3key_allKeys.extend(theseKeys)
        if len(_instruction3key_allKeys):
            instruction3key.keys = _instruction3key_allKeys[-1].name  # just the last key pressed
            instruction3key.rt = _instruction3key_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instruct3Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instruct3" ---
for thisComponent in instruct3Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instruct3" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials_3 = data.TrialHandler(nReps=3.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('block3.xlsx'),
    seed=None, name='trials_3')
thisExp.addLoop(trials_3)  # add the loop to the experiment
thisTrial_3 = trials_3.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
if thisTrial_3 != None:
    for paramName in thisTrial_3:
        exec('{} = thisTrial_3[paramName]'.format(paramName))

for thisTrial_3 in trials_3:
    currentLoop = trials_3
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
    if thisTrial_3 != None:
        for paramName in thisTrial_3:
            exec('{} = thisTrial_3[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "fixation" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # keep track of which components have finished
    fixationComponents = [text]
    for thisComponent in fixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "fixation" ---
    while continueRoutine and routineTimer.getTime() < 0.6:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 0.6-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "fixation" ---
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-0.600000)
    
    # --- Prepare to start Routine "block3" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    block3image.setImage(pic3)
    block3key.keys = []
    block3key.rt = []
    _block3key_allKeys = []
    # keep track of which components have finished
    block3Components = [block3image, block3key]
    for thisComponent in block3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "block3" ---
    while continueRoutine and routineTimer.getTime() < 1.7:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block3image* updates
        if block3image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block3image.frameNStart = frameN  # exact frame index
            block3image.tStart = t  # local t and not account for scr refresh
            block3image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block3image, 'tStartRefresh')  # time at next scr refresh
            block3image.setAutoDraw(True)
        if block3image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block3image.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block3image.tStop = t  # not accounting for scr refresh
                block3image.frameNStop = frameN  # exact frame index
                block3image.setAutoDraw(False)
        
        # *block3key* updates
        waitOnFlip = False
        if block3key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block3key.frameNStart = frameN  # exact frame index
            block3key.tStart = t  # local t and not account for scr refresh
            block3key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block3key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'block3key.started')
            block3key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(block3key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(block3key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if block3key.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block3key.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block3key.tStop = t  # not accounting for scr refresh
                block3key.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'block3key.stopped')
                block3key.status = FINISHED
        if block3key.status == STARTED and not waitOnFlip:
            theseKeys = block3key.getKeys(keyList=['f','j'], waitRelease=False)
            _block3key_allKeys.extend(theseKeys)
            if len(_block3key_allKeys):
                block3key.keys = _block3key_allKeys[-1].name  # just the last key pressed
                block3key.rt = _block3key_allKeys[-1].rt
                # was this correct?
                if (block3key.keys == str(answer3)) or (block3key.keys == answer3):
                    block3key.corr = 1
                else:
                    block3key.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in block3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "block3" ---
    for thisComponent in block3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if block3key.keys in ['', [], None]:  # No response was made
        block3key.keys = None
        # was no response the correct answer?!
        if str(answer3).lower() == 'none':
           block3key.corr = 1;  # correct non-response
        else:
           block3key.corr = 0;  # failed to respond (incorrectly)
    # store data for trials_3 (TrialHandler)
    trials_3.addData('block3key.keys',block3key.keys)
    trials_3.addData('block3key.corr', block3key.corr)
    if block3key.keys != None:  # we had a response
        trials_3.addData('block3key.rt', block3key.rt)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-1.700000)
    thisExp.nextEntry()
    
# completed 3.0 repeats of 'trials_3'


# --- Prepare to start Routine "instruct4" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instruction4key.keys = []
instruction4key.rt = []
_instruction4key_allKeys = []
# keep track of which components have finished
instruct4Components = [instruction4image, instruction4key]
for thisComponent in instruct4Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instruct4" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruction4image* updates
    if instruction4image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction4image.frameNStart = frameN  # exact frame index
        instruction4image.tStart = t  # local t and not account for scr refresh
        instruction4image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction4image, 'tStartRefresh')  # time at next scr refresh
        instruction4image.setAutoDraw(True)
    
    # *instruction4key* updates
    if instruction4key.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction4key.frameNStart = frameN  # exact frame index
        instruction4key.tStart = t  # local t and not account for scr refresh
        instruction4key.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction4key, 'tStartRefresh')  # time at next scr refresh
        instruction4key.status = STARTED
        # keyboard checking is just starting
        instruction4key.clock.reset()  # now t=0
    if instruction4key.status == STARTED:
        theseKeys = instruction4key.getKeys(keyList=['space'], waitRelease=False)
        _instruction4key_allKeys.extend(theseKeys)
        if len(_instruction4key_allKeys):
            instruction4key.keys = _instruction4key_allKeys[-1].name  # just the last key pressed
            instruction4key.rt = _instruction4key_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instruct4Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instruct4" ---
for thisComponent in instruct4Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instruct4" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials_4 = data.TrialHandler(nReps=3.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('block4.xlsx'),
    seed=None, name='trials_4')
thisExp.addLoop(trials_4)  # add the loop to the experiment
thisTrial_4 = trials_4.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
if thisTrial_4 != None:
    for paramName in thisTrial_4:
        exec('{} = thisTrial_4[paramName]'.format(paramName))

for thisTrial_4 in trials_4:
    currentLoop = trials_4
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
    if thisTrial_4 != None:
        for paramName in thisTrial_4:
            exec('{} = thisTrial_4[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "fixation" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # keep track of which components have finished
    fixationComponents = [text]
    for thisComponent in fixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "fixation" ---
    while continueRoutine and routineTimer.getTime() < 0.6:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 0.6-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "fixation" ---
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-0.600000)
    
    # --- Prepare to start Routine "block4" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    block4image.setImage(pic4)
    block4key.keys = []
    block4key.rt = []
    _block4key_allKeys = []
    # keep track of which components have finished
    block4Components = [block4image, block4key]
    for thisComponent in block4Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "block4" ---
    while continueRoutine and routineTimer.getTime() < 1.7:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block4image* updates
        if block4image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block4image.frameNStart = frameN  # exact frame index
            block4image.tStart = t  # local t and not account for scr refresh
            block4image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block4image, 'tStartRefresh')  # time at next scr refresh
            block4image.setAutoDraw(True)
        if block4image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block4image.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block4image.tStop = t  # not accounting for scr refresh
                block4image.frameNStop = frameN  # exact frame index
                block4image.setAutoDraw(False)
        
        # *block4key* updates
        waitOnFlip = False
        if block4key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block4key.frameNStart = frameN  # exact frame index
            block4key.tStart = t  # local t and not account for scr refresh
            block4key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block4key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'block4key.started')
            block4key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(block4key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(block4key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if block4key.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block4key.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block4key.tStop = t  # not accounting for scr refresh
                block4key.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'block4key.stopped')
                block4key.status = FINISHED
        if block4key.status == STARTED and not waitOnFlip:
            theseKeys = block4key.getKeys(keyList=['f','j'], waitRelease=False)
            _block4key_allKeys.extend(theseKeys)
            if len(_block4key_allKeys):
                block4key.keys = _block4key_allKeys[-1].name  # just the last key pressed
                block4key.rt = _block4key_allKeys[-1].rt
                # was this correct?
                if (block4key.keys == str(answer4)) or (block4key.keys == answer4):
                    block4key.corr = 1
                else:
                    block4key.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in block4Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "block4" ---
    for thisComponent in block4Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if block4key.keys in ['', [], None]:  # No response was made
        block4key.keys = None
        # was no response the correct answer?!
        if str(answer4).lower() == 'none':
           block4key.corr = 1;  # correct non-response
        else:
           block4key.corr = 0;  # failed to respond (incorrectly)
    # store data for trials_4 (TrialHandler)
    trials_4.addData('block4key.keys',block4key.keys)
    trials_4.addData('block4key.corr', block4key.corr)
    if block4key.keys != None:  # we had a response
        trials_4.addData('block4key.rt', block4key.rt)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-1.700000)
    thisExp.nextEntry()
    
# completed 3.0 repeats of 'trials_4'


# --- Prepare to start Routine "instruct5" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instruction5key.keys = []
instruction5key.rt = []
_instruction5key_allKeys = []
# keep track of which components have finished
instruct5Components = [instruction5image, instruction5key]
for thisComponent in instruct5Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instruct5" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruction5image* updates
    if instruction5image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction5image.frameNStart = frameN  # exact frame index
        instruction5image.tStart = t  # local t and not account for scr refresh
        instruction5image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction5image, 'tStartRefresh')  # time at next scr refresh
        instruction5image.setAutoDraw(True)
    
    # *instruction5key* updates
    if instruction5key.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction5key.frameNStart = frameN  # exact frame index
        instruction5key.tStart = t  # local t and not account for scr refresh
        instruction5key.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction5key, 'tStartRefresh')  # time at next scr refresh
        instruction5key.status = STARTED
        # keyboard checking is just starting
        instruction5key.clock.reset()  # now t=0
    if instruction5key.status == STARTED:
        theseKeys = instruction5key.getKeys(keyList=['space'], waitRelease=False)
        _instruction5key_allKeys.extend(theseKeys)
        if len(_instruction5key_allKeys):
            instruction5key.keys = _instruction5key_allKeys[-1].name  # just the last key pressed
            instruction5key.rt = _instruction5key_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instruct5Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instruct5" ---
for thisComponent in instruct5Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instruct5" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials_5 = data.TrialHandler(nReps=3.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('block5.xlsx'),
    seed=None, name='trials_5')
thisExp.addLoop(trials_5)  # add the loop to the experiment
thisTrial_5 = trials_5.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial_5.rgb)
if thisTrial_5 != None:
    for paramName in thisTrial_5:
        exec('{} = thisTrial_5[paramName]'.format(paramName))

for thisTrial_5 in trials_5:
    currentLoop = trials_5
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_5.rgb)
    if thisTrial_5 != None:
        for paramName in thisTrial_5:
            exec('{} = thisTrial_5[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "fixation" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # keep track of which components have finished
    fixationComponents = [text]
    for thisComponent in fixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "fixation" ---
    while continueRoutine and routineTimer.getTime() < 0.6:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 0.6-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "fixation" ---
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-0.600000)
    
    # --- Prepare to start Routine "block5" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    block5image.setImage(pic5)
    block5key.keys = []
    block5key.rt = []
    _block5key_allKeys = []
    # keep track of which components have finished
    block5Components = [block5image, block5key]
    for thisComponent in block5Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "block5" ---
    while continueRoutine and routineTimer.getTime() < 1.7:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block5image* updates
        if block5image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block5image.frameNStart = frameN  # exact frame index
            block5image.tStart = t  # local t and not account for scr refresh
            block5image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block5image, 'tStartRefresh')  # time at next scr refresh
            block5image.setAutoDraw(True)
        if block5image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block5image.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block5image.tStop = t  # not accounting for scr refresh
                block5image.frameNStop = frameN  # exact frame index
                block5image.setAutoDraw(False)
        
        # *block5key* updates
        waitOnFlip = False
        if block5key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block5key.frameNStart = frameN  # exact frame index
            block5key.tStart = t  # local t and not account for scr refresh
            block5key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block5key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'block5key.started')
            block5key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(block5key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(block5key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if block5key.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block5key.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block5key.tStop = t  # not accounting for scr refresh
                block5key.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'block5key.stopped')
                block5key.status = FINISHED
        if block5key.status == STARTED and not waitOnFlip:
            theseKeys = block5key.getKeys(keyList=['f','j'], waitRelease=False)
            _block5key_allKeys.extend(theseKeys)
            if len(_block5key_allKeys):
                block5key.keys = _block5key_allKeys[-1].name  # just the last key pressed
                block5key.rt = _block5key_allKeys[-1].rt
                # was this correct?
                if (block5key.keys == str(answer5)) or (block5key.keys == answer5):
                    block5key.corr = 1
                else:
                    block5key.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in block5Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "block5" ---
    for thisComponent in block5Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if block5key.keys in ['', [], None]:  # No response was made
        block5key.keys = None
        # was no response the correct answer?!
        if str(answer5).lower() == 'none':
           block5key.corr = 1;  # correct non-response
        else:
           block5key.corr = 0;  # failed to respond (incorrectly)
    # store data for trials_5 (TrialHandler)
    trials_5.addData('block5key.keys',block5key.keys)
    trials_5.addData('block5key.corr', block5key.corr)
    if block5key.keys != None:  # we had a response
        trials_5.addData('block5key.rt', block5key.rt)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-1.700000)
    thisExp.nextEntry()
    
# completed 3.0 repeats of 'trials_5'


# --- Prepare to start Routine "instruct6" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instruction6key.keys = []
instruction6key.rt = []
_instruction6key_allKeys = []
# keep track of which components have finished
instruct6Components = [instruction6image, instruction6key]
for thisComponent in instruct6Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instruct6" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruction6image* updates
    if instruction6image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction6image.frameNStart = frameN  # exact frame index
        instruction6image.tStart = t  # local t and not account for scr refresh
        instruction6image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction6image, 'tStartRefresh')  # time at next scr refresh
        instruction6image.setAutoDraw(True)
    
    # *instruction6key* updates
    if instruction6key.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruction6key.frameNStart = frameN  # exact frame index
        instruction6key.tStart = t  # local t and not account for scr refresh
        instruction6key.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruction6key, 'tStartRefresh')  # time at next scr refresh
        instruction6key.status = STARTED
        # keyboard checking is just starting
        instruction6key.clock.reset()  # now t=0
    if instruction6key.status == STARTED:
        theseKeys = instruction6key.getKeys(keyList=['space'], waitRelease=False)
        _instruction6key_allKeys.extend(theseKeys)
        if len(_instruction6key_allKeys):
            instruction6key.keys = _instruction6key_allKeys[-1].name  # just the last key pressed
            instruction6key.rt = _instruction6key_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instruct6Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instruct6" ---
for thisComponent in instruct6Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instruct6" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials_6 = data.TrialHandler(nReps=3.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('block6.xlsx'),
    seed=None, name='trials_6')
thisExp.addLoop(trials_6)  # add the loop to the experiment
thisTrial_6 = trials_6.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial_6.rgb)
if thisTrial_6 != None:
    for paramName in thisTrial_6:
        exec('{} = thisTrial_6[paramName]'.format(paramName))

for thisTrial_6 in trials_6:
    currentLoop = trials_6
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_6.rgb)
    if thisTrial_6 != None:
        for paramName in thisTrial_6:
            exec('{} = thisTrial_6[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "fixation" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # keep track of which components have finished
    fixationComponents = [text]
    for thisComponent in fixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "fixation" ---
    while continueRoutine and routineTimer.getTime() < 0.6:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 0.6-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "fixation" ---
    for thisComponent in fixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-0.600000)
    
    # --- Prepare to start Routine "block6" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    block6image.setImage(pic6)
    block6key.keys = []
    block6key.rt = []
    _block6key_allKeys = []
    # keep track of which components have finished
    block6Components = [block6image, block6key]
    for thisComponent in block6Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "block6" ---
    while continueRoutine and routineTimer.getTime() < 1.7:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *block6image* updates
        if block6image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block6image.frameNStart = frameN  # exact frame index
            block6image.tStart = t  # local t and not account for scr refresh
            block6image.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block6image, 'tStartRefresh')  # time at next scr refresh
            block6image.setAutoDraw(True)
        if block6image.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block6image.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block6image.tStop = t  # not accounting for scr refresh
                block6image.frameNStop = frameN  # exact frame index
                block6image.setAutoDraw(False)
        
        # *block6key* updates
        waitOnFlip = False
        if block6key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            block6key.frameNStart = frameN  # exact frame index
            block6key.tStart = t  # local t and not account for scr refresh
            block6key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(block6key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'block6key.started')
            block6key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(block6key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(block6key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if block6key.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > block6key.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                block6key.tStop = t  # not accounting for scr refresh
                block6key.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'block6key.stopped')
                block6key.status = FINISHED
        if block6key.status == STARTED and not waitOnFlip:
            theseKeys = block6key.getKeys(keyList=['f','j'], waitRelease=False)
            _block6key_allKeys.extend(theseKeys)
            if len(_block6key_allKeys):
                block6key.keys = _block6key_allKeys[-1].name  # just the last key pressed
                block6key.rt = _block6key_allKeys[-1].rt
                # was this correct?
                if (block6key.keys == str(answer6)) or (block6key.keys == answer6):
                    block6key.corr = 1
                else:
                    block6key.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in block6Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "block6" ---
    for thisComponent in block6Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if block6key.keys in ['', [], None]:  # No response was made
        block6key.keys = None
        # was no response the correct answer?!
        if str(answer6).lower() == 'none':
           block6key.corr = 1;  # correct non-response
        else:
           block6key.corr = 0;  # failed to respond (incorrectly)
    # store data for trials_6 (TrialHandler)
    trials_6.addData('block6key.keys',block6key.keys)
    trials_6.addData('block6key.corr', block6key.corr)
    if block6key.keys != None:  # we had a response
        trials_6.addData('block6key.rt', block6key.rt)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-1.700000)
    thisExp.nextEntry()
    
# completed 3.0 repeats of 'trials_6'


# --- Prepare to start Routine "END" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
quitkey.keys = []
quitkey.rt = []
_quitkey_allKeys = []
# keep track of which components have finished
ENDComponents = [quit, quitkey]
for thisComponent in ENDComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "END" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *quit* updates
    if quit.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        quit.frameNStart = frameN  # exact frame index
        quit.tStart = t  # local t and not account for scr refresh
        quit.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(quit, 'tStartRefresh')  # time at next scr refresh
        quit.setAutoDraw(True)
    
    # *quitkey* updates
    if quitkey.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        quitkey.frameNStart = frameN  # exact frame index
        quitkey.tStart = t  # local t and not account for scr refresh
        quitkey.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(quitkey, 'tStartRefresh')  # time at next scr refresh
        quitkey.status = STARTED
        # keyboard checking is just starting
        quitkey.clock.reset()  # now t=0
    if quitkey.status == STARTED:
        theseKeys = quitkey.getKeys(keyList=['space'], waitRelease=False)
        _quitkey_allKeys.extend(theseKeys)
        if len(_quitkey_allKeys):
            quitkey.keys = _quitkey_allKeys[-1].name  # just the last key pressed
            quitkey.rt = _quitkey_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in ENDComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "END" ---
for thisComponent in ENDComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "END" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
