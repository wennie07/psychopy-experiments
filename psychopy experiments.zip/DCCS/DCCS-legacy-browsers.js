﻿/************* 
 * Dccs Test *
 *************/


// store info about the experiment session:
let expName = 'DCCS';  // from the Builder filename that created this script
let expInfo = {
    'participant': '',
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color('white'),
  units: 'height',
  waitBlanking: true
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(instruct1RoutineBegin());
flowScheduler.add(instruct1RoutineEachFrame());
flowScheduler.add(instruct1RoutineEnd());
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin(trialsLoopScheduler));
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);
flowScheduler.add(instruct2RoutineBegin());
flowScheduler.add(instruct2RoutineEachFrame());
flowScheduler.add(instruct2RoutineEnd());
const trials_2LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_2LoopBegin(trials_2LoopScheduler));
flowScheduler.add(trials_2LoopScheduler);
flowScheduler.add(trials_2LoopEnd);
flowScheduler.add(instruct3RoutineBegin());
flowScheduler.add(instruct3RoutineEachFrame());
flowScheduler.add(instruct3RoutineEnd());
const trials_3LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_3LoopBegin(trials_3LoopScheduler));
flowScheduler.add(trials_3LoopScheduler);
flowScheduler.add(trials_3LoopEnd);
flowScheduler.add(instruct4RoutineBegin());
flowScheduler.add(instruct4RoutineEachFrame());
flowScheduler.add(instruct4RoutineEnd());
const trials_4LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_4LoopBegin(trials_4LoopScheduler));
flowScheduler.add(trials_4LoopScheduler);
flowScheduler.add(trials_4LoopEnd);
flowScheduler.add(instruct5RoutineBegin());
flowScheduler.add(instruct5RoutineEachFrame());
flowScheduler.add(instruct5RoutineEnd());
const trials_5LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_5LoopBegin(trials_5LoopScheduler));
flowScheduler.add(trials_5LoopScheduler);
flowScheduler.add(trials_5LoopEnd);
flowScheduler.add(instruct6RoutineBegin());
flowScheduler.add(instruct6RoutineEachFrame());
flowScheduler.add(instruct6RoutineEnd());
const trials_6LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_6LoopBegin(trials_6LoopScheduler));
flowScheduler.add(trials_6LoopScheduler);
flowScheduler.add(trials_6LoopEnd);
flowScheduler.add(ENDRoutineBegin());
flowScheduler.add(ENDRoutineEachFrame());
flowScheduler.add(ENDRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    {'name': 'block5.xlsx', 'path': 'block5.xlsx'},
    {'name': 'block2.xlsx', 'path': 'block2.xlsx'},
    {'name': '1_1.png', 'path': '1_1.png'},
    {'name': '1_3.png', 'path': '1_3.png'},
    {'name': '1_2.png', 'path': '1_2.png'},
    {'name': '2_1.png', 'path': '2_1.png'},
    {'name': '2_3.png', 'path': '2_3.png'},
    {'name': 'block1.xlsx', 'path': 'block1.xlsx'},
    {'name': 'block6.xlsx', 'path': 'block6.xlsx'},
    {'name': 'block4.xlsx', 'path': 'block4.xlsx'},
    {'name': '2_2.png', 'path': '2_2.png'},
    {'name': 'block3.xlsx', 'path': 'block3.xlsx'}
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2022.2.5';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  

  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);


  return Scheduler.Event.NEXT;
}


var instruct1Clock;
var instruction1image;
var instruction1key;
var fixationClock;
var text;
var block1Clock;
var cortex_rec_4;
var block1image;
var block1key_resp;
var eeg_marker_4;
var instruct2Clock;
var instruction2image;
var instruction2ke;
var block2Clock;
var cortex_rec_5;
var block2image;
var block2key_resp;
var eeg_marker_5;
var instruct3Clock;
var instruction3image;
var instruction3key;
var block3Clock;
var cortex_rec_6;
var block3image;
var block3key;
var eeg_marker_6;
var instruct4Clock;
var instruction4image;
var instruction4key;
var block4Clock;
var cortex_rec;
var block4image;
var block4key;
var eeg_marker;
var instruct5Clock;
var instruction5image;
var instruction5key;
var block5Clock;
var cortex_rec_2;
var block5image;
var block5key;
var eeg_marker_2;
var instruct6Clock;
var instruction6image;
var instruction6key;
var block6Clock;
var cortex_rec_3;
var block6image;
var block6key;
var eeg_marker_3;
var ENDClock;
var quit;
var quitkey;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "instruct1"
  instruct1Clock = new util.Clock();
  instruction1image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction1image', units : undefined, 
    image : '1_1.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  instruction1key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "fixation"
  fixationClock = new util.Clock();
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: '+',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "block1"
  block1Clock = new util.Clock();
  cortex_rec_4 = {"status": "PsychoJS.Status.NOT_STARTED"};
  block1image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block1image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  block1key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  eeg_marker_4 = {status: PsychoJS.Status.NOT_STARTED,setMarker_label: function(label) {},setMarker_value: function(value) {} };
  // Initialize components for Routine "instruct2"
  instruct2Clock = new util.Clock();
  instruction2image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction2image', units : undefined, 
    image : '1_2.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  instruction2ke = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "block2"
  block2Clock = new util.Clock();
  cortex_rec_5 = {"status": "PsychoJS.Status.NOT_STARTED"};
  block2image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block2image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  block2key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  eeg_marker_5 = {status: PsychoJS.Status.NOT_STARTED,setMarker_label: function(label) {},setMarker_value: function(value) {} };
  // Initialize components for Routine "instruct3"
  instruct3Clock = new util.Clock();
  instruction3image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction3image', units : undefined, 
    image : '1_3.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  instruction3key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "block3"
  block3Clock = new util.Clock();
  cortex_rec_6 = {"status": "PsychoJS.Status.NOT_STARTED"};
  block3image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block3image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  block3key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  eeg_marker_6 = {status: PsychoJS.Status.NOT_STARTED,setMarker_label: function(label) {},setMarker_value: function(value) {} };
  // Initialize components for Routine "instruct4"
  instruct4Clock = new util.Clock();
  instruction4image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction4image', units : undefined, 
    image : '2_1.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  instruction4key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "block4"
  block4Clock = new util.Clock();
  cortex_rec = {"status": "PsychoJS.Status.NOT_STARTED"};
  block4image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block4image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  block4key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  eeg_marker = {status: PsychoJS.Status.NOT_STARTED,setMarker_label: function(label) {},setMarker_value: function(value) {} };
  // Initialize components for Routine "instruct5"
  instruct5Clock = new util.Clock();
  instruction5image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction5image', units : undefined, 
    image : '2_2.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  instruction5key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "block5"
  block5Clock = new util.Clock();
  cortex_rec_2 = {"status": "PsychoJS.Status.NOT_STARTED"};
  block5image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block5image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  block5key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  eeg_marker_2 = {status: PsychoJS.Status.NOT_STARTED,setMarker_label: function(label) {},setMarker_value: function(value) {} };
  // Initialize components for Routine "instruct6"
  instruct6Clock = new util.Clock();
  instruction6image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction6image', units : undefined, 
    image : '2_3.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  instruction6key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "block6"
  block6Clock = new util.Clock();
  cortex_rec_3 = {"status": "PsychoJS.Status.NOT_STARTED"};
  block6image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block6image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  block6key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  eeg_marker_3 = {status: PsychoJS.Status.NOT_STARTED,setMarker_label: function(label) {},setMarker_value: function(value) {} };
  // Initialize components for Routine "END"
  ENDClock = new util.Clock();
  quit = new visual.ImageStim({
    win : psychoJS.window,
    name : 'quit', units : undefined, 
    image : '完成啦.bmp', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  quitkey = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var _instruction1key_allKeys;
var instruct1Components;
function instruct1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct1' ---
    t = 0;
    instruct1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instruction1key.keys = undefined;
    instruction1key.rt = undefined;
    _instruction1key_allKeys = [];
    // keep track of which components have finished
    instruct1Components = [];
    instruct1Components.push(instruction1image);
    instruct1Components.push(instruction1key);
    
    instruct1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function instruct1RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct1' ---
    // get current time
    t = instruct1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction1image* updates
    if (t >= 0.0 && instruction1image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction1image.tStart = t;  // (not accounting for frame time here)
      instruction1image.frameNStart = frameN;  // exact frame index
      
      instruction1image.setAutoDraw(true);
    }

    
    // *instruction1key* updates
    if (t >= 0.0 && instruction1key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction1key.tStart = t;  // (not accounting for frame time here)
      instruction1key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      instruction1key.clock.reset();
      instruction1key.start();
    }

    if (instruction1key.status === PsychoJS.Status.STARTED) {
      let theseKeys = instruction1key.getKeys({keyList: ['space'], waitRelease: false});
      _instruction1key_allKeys = _instruction1key_allKeys.concat(theseKeys);
      if (_instruction1key_allKeys.length > 0) {
        instruction1key.keys = _instruction1key_allKeys[_instruction1key_allKeys.length - 1].name;  // just the last key pressed
        instruction1key.rt = _instruction1key_allKeys[_instruction1key_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instruct1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct1' ---
    instruct1Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    instruction1key.stop();
    // the Routine "instruct1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var trials;
function trialsLoopBegin(trialsLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 3, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block1.xlsx',
      seed: undefined, name: 'trials'
    });
    psychoJS.experiment.addLoop(trials); // add the loop to the experiment
    currentLoop = trials;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials.forEach(function() {
      snapshot = trials.getSnapshot();
    
      trialsLoopScheduler.add(importConditions(snapshot));
      trialsLoopScheduler.add(fixationRoutineBegin(snapshot));
      trialsLoopScheduler.add(fixationRoutineEachFrame());
      trialsLoopScheduler.add(fixationRoutineEnd(snapshot));
      trialsLoopScheduler.add(block1RoutineBegin(snapshot));
      trialsLoopScheduler.add(block1RoutineEachFrame());
      trialsLoopScheduler.add(block1RoutineEnd(snapshot));
      trialsLoopScheduler.add(trialsLoopEndIteration(trialsLoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function trialsLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trialsLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_2;
function trials_2LoopBegin(trials_2LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_2 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 3, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block2.xlsx',
      seed: undefined, name: 'trials_2'
    });
    psychoJS.experiment.addLoop(trials_2); // add the loop to the experiment
    currentLoop = trials_2;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials_2.forEach(function() {
      snapshot = trials_2.getSnapshot();
    
      trials_2LoopScheduler.add(importConditions(snapshot));
      trials_2LoopScheduler.add(fixationRoutineBegin(snapshot));
      trials_2LoopScheduler.add(fixationRoutineEachFrame());
      trials_2LoopScheduler.add(fixationRoutineEnd(snapshot));
      trials_2LoopScheduler.add(block2RoutineBegin(snapshot));
      trials_2LoopScheduler.add(block2RoutineEachFrame());
      trials_2LoopScheduler.add(block2RoutineEnd(snapshot));
      trials_2LoopScheduler.add(trials_2LoopEndIteration(trials_2LoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_2LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_2);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_2LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_3;
function trials_3LoopBegin(trials_3LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_3 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 3, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block3.xlsx',
      seed: undefined, name: 'trials_3'
    });
    psychoJS.experiment.addLoop(trials_3); // add the loop to the experiment
    currentLoop = trials_3;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials_3.forEach(function() {
      snapshot = trials_3.getSnapshot();
    
      trials_3LoopScheduler.add(importConditions(snapshot));
      trials_3LoopScheduler.add(fixationRoutineBegin(snapshot));
      trials_3LoopScheduler.add(fixationRoutineEachFrame());
      trials_3LoopScheduler.add(fixationRoutineEnd(snapshot));
      trials_3LoopScheduler.add(block3RoutineBegin(snapshot));
      trials_3LoopScheduler.add(block3RoutineEachFrame());
      trials_3LoopScheduler.add(block3RoutineEnd(snapshot));
      trials_3LoopScheduler.add(trials_3LoopEndIteration(trials_3LoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_3LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_3);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_3LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_4;
function trials_4LoopBegin(trials_4LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_4 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 3, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block4.xlsx',
      seed: undefined, name: 'trials_4'
    });
    psychoJS.experiment.addLoop(trials_4); // add the loop to the experiment
    currentLoop = trials_4;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials_4.forEach(function() {
      snapshot = trials_4.getSnapshot();
    
      trials_4LoopScheduler.add(importConditions(snapshot));
      trials_4LoopScheduler.add(fixationRoutineBegin(snapshot));
      trials_4LoopScheduler.add(fixationRoutineEachFrame());
      trials_4LoopScheduler.add(fixationRoutineEnd(snapshot));
      trials_4LoopScheduler.add(block4RoutineBegin(snapshot));
      trials_4LoopScheduler.add(block4RoutineEachFrame());
      trials_4LoopScheduler.add(block4RoutineEnd(snapshot));
      trials_4LoopScheduler.add(trials_4LoopEndIteration(trials_4LoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_4LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_4);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_4LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_5;
function trials_5LoopBegin(trials_5LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_5 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 3, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block5.xlsx',
      seed: undefined, name: 'trials_5'
    });
    psychoJS.experiment.addLoop(trials_5); // add the loop to the experiment
    currentLoop = trials_5;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials_5.forEach(function() {
      snapshot = trials_5.getSnapshot();
    
      trials_5LoopScheduler.add(importConditions(snapshot));
      trials_5LoopScheduler.add(fixationRoutineBegin(snapshot));
      trials_5LoopScheduler.add(fixationRoutineEachFrame());
      trials_5LoopScheduler.add(fixationRoutineEnd(snapshot));
      trials_5LoopScheduler.add(block5RoutineBegin(snapshot));
      trials_5LoopScheduler.add(block5RoutineEachFrame());
      trials_5LoopScheduler.add(block5RoutineEnd(snapshot));
      trials_5LoopScheduler.add(trials_5LoopEndIteration(trials_5LoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_5LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_5);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_5LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_6;
function trials_6LoopBegin(trials_6LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_6 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 3, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block6.xlsx',
      seed: undefined, name: 'trials_6'
    });
    psychoJS.experiment.addLoop(trials_6); // add the loop to the experiment
    currentLoop = trials_6;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    trials_6.forEach(function() {
      snapshot = trials_6.getSnapshot();
    
      trials_6LoopScheduler.add(importConditions(snapshot));
      trials_6LoopScheduler.add(fixationRoutineBegin(snapshot));
      trials_6LoopScheduler.add(fixationRoutineEachFrame());
      trials_6LoopScheduler.add(fixationRoutineEnd(snapshot));
      trials_6LoopScheduler.add(block6RoutineBegin(snapshot));
      trials_6LoopScheduler.add(block6RoutineEachFrame());
      trials_6LoopScheduler.add(block6RoutineEnd(snapshot));
      trials_6LoopScheduler.add(trials_6LoopEndIteration(trials_6LoopScheduler, snapshot));
    });
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_6LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_6);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_6LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var fixationComponents;
function fixationRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'fixation' ---
    t = 0;
    fixationClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(0.600000);
    // update component parameters for each repeat
    // keep track of which components have finished
    fixationComponents = [];
    fixationComponents.push(text);
    
    fixationComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function fixationRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'fixation' ---
    // get current time
    t = fixationClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text* updates
    if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text.tStart = t;  // (not accounting for frame time here)
      text.frameNStart = frameN;  // exact frame index
      
      text.setAutoDraw(true);
    }

    frameRemains = 0.0 + 0.6 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (text.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    fixationComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function fixationRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'fixation' ---
    fixationComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block1key_resp_allKeys;
var block1Components;
function block1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block1' ---
    t = 0;
    block1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block1image.setImage(pic1);
    block1key_resp.keys = undefined;
    block1key_resp.rt = undefined;
    _block1key_resp_allKeys = [];
    // keep track of which components have finished
    block1Components = [];
    block1Components.push(cortex_rec_4);
    block1Components.push(block1image);
    block1Components.push(block1key_resp);
    block1Components.push(eeg_marker_4);
    
    block1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function block1RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block1' ---
    // get current time
    t = block1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block1image* updates
    if (t >= 0.0 && block1image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block1image.tStart = t;  // (not accounting for frame time here)
      block1image.frameNStart = frameN;  // exact frame index
      
      block1image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block1image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block1image.setAutoDraw(false);
    }
    
    // *block1key_resp* updates
    if (t >= 0.0 && block1key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block1key_resp.tStart = t;  // (not accounting for frame time here)
      block1key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block1key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block1key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block1key_resp.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block1key_resp.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block1key_resp.status = PsychoJS.Status.FINISHED;
  }

    if (block1key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = block1key_resp.getKeys({keyList: ['f', 'j'], waitRelease: false});
      _block1key_resp_allKeys = _block1key_resp_allKeys.concat(theseKeys);
      if (_block1key_resp_allKeys.length > 0) {
        block1key_resp.keys = _block1key_resp_allKeys[_block1key_resp_allKeys.length - 1].name;  // just the last key pressed
        block1key_resp.rt = _block1key_resp_allKeys[_block1key_resp_allKeys.length - 1].rt;
        // was this correct?
        if (block1key_resp.keys == answer1) {
            block1key_resp.corr = 1;
        } else {
            block1key_resp.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // eeg_marker_4 updates
    if (t >= 0.0 && eeg_marker_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      eeg_marker_4.tStart = t;  // (not accounting for frame time here)
      eeg_marker_4.frameNStart = frameN;  // exact frame index
      
      psychoJS.window.callOnFlip(function() {
        if (typeof emotiv != "undefined") {
          emotiv.sendMarker('1'.toString(), 'label'.toString(), false)
        }
      });
      eeg_marker_4.status = PsychoJS.Status.STARTED;
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (eeg_marker_4.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      eeg_marker_4.status = PsychoJS.Status.FINISHED;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    block1Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block1' ---
    block1Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (block1key_resp.keys === undefined) {
      if (['None','none',undefined].includes(answer1)) {
         block1key_resp.corr = 1;  // correct non-response
      } else {
         block1key_resp.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block1key_resp.corr, level);
    }
    psychoJS.experiment.addData('block1key_resp.keys', block1key_resp.keys);
    psychoJS.experiment.addData('block1key_resp.corr', block1key_resp.corr);
    if (typeof block1key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block1key_resp.rt', block1key_resp.rt);
        routineTimer.reset();
        }
    
    block1key_resp.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _instruction2ke_allKeys;
var instruct2Components;
function instruct2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct2' ---
    t = 0;
    instruct2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instruction2ke.keys = undefined;
    instruction2ke.rt = undefined;
    _instruction2ke_allKeys = [];
    // keep track of which components have finished
    instruct2Components = [];
    instruct2Components.push(instruction2image);
    instruct2Components.push(instruction2ke);
    
    instruct2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function instruct2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct2' ---
    // get current time
    t = instruct2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction2image* updates
    if (t >= 0.0 && instruction2image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction2image.tStart = t;  // (not accounting for frame time here)
      instruction2image.frameNStart = frameN;  // exact frame index
      
      instruction2image.setAutoDraw(true);
    }

    
    // *instruction2ke* updates
    if (t >= 0.0 && instruction2ke.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction2ke.tStart = t;  // (not accounting for frame time here)
      instruction2ke.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      instruction2ke.clock.reset();
      instruction2ke.start();
    }

    if (instruction2ke.status === PsychoJS.Status.STARTED) {
      let theseKeys = instruction2ke.getKeys({keyList: ['space'], waitRelease: false});
      _instruction2ke_allKeys = _instruction2ke_allKeys.concat(theseKeys);
      if (_instruction2ke_allKeys.length > 0) {
        instruction2ke.keys = _instruction2ke_allKeys[_instruction2ke_allKeys.length - 1].name;  // just the last key pressed
        instruction2ke.rt = _instruction2ke_allKeys[_instruction2ke_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instruct2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct2' ---
    instruct2Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    instruction2ke.stop();
    // the Routine "instruct2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block2key_resp_allKeys;
var block2Components;
function block2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block2' ---
    t = 0;
    block2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block2image.setImage(pic2);
    block2key_resp.keys = undefined;
    block2key_resp.rt = undefined;
    _block2key_resp_allKeys = [];
    // keep track of which components have finished
    block2Components = [];
    block2Components.push(cortex_rec_5);
    block2Components.push(block2image);
    block2Components.push(block2key_resp);
    block2Components.push(eeg_marker_5);
    
    block2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function block2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block2' ---
    // get current time
    t = block2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block2image* updates
    if (t >= 0.0 && block2image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block2image.tStart = t;  // (not accounting for frame time here)
      block2image.frameNStart = frameN;  // exact frame index
      
      block2image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block2image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block2image.setAutoDraw(false);
    }
    
    // *block2key_resp* updates
    if (t >= 0.0 && block2key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block2key_resp.tStart = t;  // (not accounting for frame time here)
      block2key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block2key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block2key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block2key_resp.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block2key_resp.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block2key_resp.status = PsychoJS.Status.FINISHED;
  }

    if (block2key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = block2key_resp.getKeys({keyList: ['f', 'j'], waitRelease: false});
      _block2key_resp_allKeys = _block2key_resp_allKeys.concat(theseKeys);
      if (_block2key_resp_allKeys.length > 0) {
        block2key_resp.keys = _block2key_resp_allKeys[_block2key_resp_allKeys.length - 1].name;  // just the last key pressed
        block2key_resp.rt = _block2key_resp_allKeys[_block2key_resp_allKeys.length - 1].rt;
        // was this correct?
        if (block2key_resp.keys == answer2) {
            block2key_resp.corr = 1;
        } else {
            block2key_resp.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // eeg_marker_5 updates
    if (t >= 0.0 && eeg_marker_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      eeg_marker_5.tStart = t;  // (not accounting for frame time here)
      eeg_marker_5.frameNStart = frameN;  // exact frame index
      
      psychoJS.window.callOnFlip(function() {
        if (typeof emotiv != "undefined") {
          emotiv.sendMarker('1'.toString(), 'label'.toString(), false)
        }
      });
      eeg_marker_5.status = PsychoJS.Status.STARTED;
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (eeg_marker_5.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      eeg_marker_5.status = PsychoJS.Status.FINISHED;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    block2Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block2' ---
    block2Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (block2key_resp.keys === undefined) {
      if (['None','none',undefined].includes(answer2)) {
         block2key_resp.corr = 1;  // correct non-response
      } else {
         block2key_resp.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block2key_resp.corr, level);
    }
    psychoJS.experiment.addData('block2key_resp.keys', block2key_resp.keys);
    psychoJS.experiment.addData('block2key_resp.corr', block2key_resp.corr);
    if (typeof block2key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block2key_resp.rt', block2key_resp.rt);
        routineTimer.reset();
        }
    
    block2key_resp.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _instruction3key_allKeys;
var instruct3Components;
function instruct3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct3' ---
    t = 0;
    instruct3Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instruction3key.keys = undefined;
    instruction3key.rt = undefined;
    _instruction3key_allKeys = [];
    // keep track of which components have finished
    instruct3Components = [];
    instruct3Components.push(instruction3image);
    instruct3Components.push(instruction3key);
    
    instruct3Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function instruct3RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct3' ---
    // get current time
    t = instruct3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction3image* updates
    if (t >= 0.0 && instruction3image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction3image.tStart = t;  // (not accounting for frame time here)
      instruction3image.frameNStart = frameN;  // exact frame index
      
      instruction3image.setAutoDraw(true);
    }

    
    // *instruction3key* updates
    if (t >= 0.0 && instruction3key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction3key.tStart = t;  // (not accounting for frame time here)
      instruction3key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      instruction3key.clock.reset();
      instruction3key.start();
    }

    if (instruction3key.status === PsychoJS.Status.STARTED) {
      let theseKeys = instruction3key.getKeys({keyList: ['space'], waitRelease: false});
      _instruction3key_allKeys = _instruction3key_allKeys.concat(theseKeys);
      if (_instruction3key_allKeys.length > 0) {
        instruction3key.keys = _instruction3key_allKeys[_instruction3key_allKeys.length - 1].name;  // just the last key pressed
        instruction3key.rt = _instruction3key_allKeys[_instruction3key_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instruct3Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct3RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct3' ---
    instruct3Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    instruction3key.stop();
    // the Routine "instruct3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block3key_allKeys;
var block3Components;
function block3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block3' ---
    t = 0;
    block3Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block3image.setImage(pic3);
    block3key.keys = undefined;
    block3key.rt = undefined;
    _block3key_allKeys = [];
    // keep track of which components have finished
    block3Components = [];
    block3Components.push(cortex_rec_6);
    block3Components.push(block3image);
    block3Components.push(block3key);
    block3Components.push(eeg_marker_6);
    
    block3Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function block3RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block3' ---
    // get current time
    t = block3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block3image* updates
    if (t >= 0.0 && block3image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block3image.tStart = t;  // (not accounting for frame time here)
      block3image.frameNStart = frameN;  // exact frame index
      
      block3image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block3image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block3image.setAutoDraw(false);
    }
    
    // *block3key* updates
    if (t >= 0.0 && block3key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block3key.tStart = t;  // (not accounting for frame time here)
      block3key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block3key.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block3key.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block3key.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block3key.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block3key.status = PsychoJS.Status.FINISHED;
  }

    if (block3key.status === PsychoJS.Status.STARTED) {
      let theseKeys = block3key.getKeys({keyList: ['f', 'j'], waitRelease: false});
      _block3key_allKeys = _block3key_allKeys.concat(theseKeys);
      if (_block3key_allKeys.length > 0) {
        block3key.keys = _block3key_allKeys[_block3key_allKeys.length - 1].name;  // just the last key pressed
        block3key.rt = _block3key_allKeys[_block3key_allKeys.length - 1].rt;
        // was this correct?
        if (block3key.keys == answer3) {
            block3key.corr = 1;
        } else {
            block3key.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // eeg_marker_6 updates
    if (t >= 0.0 && eeg_marker_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      eeg_marker_6.tStart = t;  // (not accounting for frame time here)
      eeg_marker_6.frameNStart = frameN;  // exact frame index
      
      psychoJS.window.callOnFlip(function() {
        if (typeof emotiv != "undefined") {
          emotiv.sendMarker('1'.toString(), 'label'.toString(), false)
        }
      });
      eeg_marker_6.status = PsychoJS.Status.STARTED;
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (eeg_marker_6.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      eeg_marker_6.status = PsychoJS.Status.FINISHED;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    block3Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block3RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block3' ---
    block3Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (block3key.keys === undefined) {
      if (['None','none',undefined].includes(answer3)) {
         block3key.corr = 1;  // correct non-response
      } else {
         block3key.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block3key.corr, level);
    }
    psychoJS.experiment.addData('block3key.keys', block3key.keys);
    psychoJS.experiment.addData('block3key.corr', block3key.corr);
    if (typeof block3key.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block3key.rt', block3key.rt);
        routineTimer.reset();
        }
    
    block3key.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _instruction4key_allKeys;
var instruct4Components;
function instruct4RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct4' ---
    t = 0;
    instruct4Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instruction4key.keys = undefined;
    instruction4key.rt = undefined;
    _instruction4key_allKeys = [];
    // keep track of which components have finished
    instruct4Components = [];
    instruct4Components.push(instruction4image);
    instruct4Components.push(instruction4key);
    
    instruct4Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function instruct4RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct4' ---
    // get current time
    t = instruct4Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction4image* updates
    if (t >= 0.0 && instruction4image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction4image.tStart = t;  // (not accounting for frame time here)
      instruction4image.frameNStart = frameN;  // exact frame index
      
      instruction4image.setAutoDraw(true);
    }

    
    // *instruction4key* updates
    if (t >= 0.0 && instruction4key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction4key.tStart = t;  // (not accounting for frame time here)
      instruction4key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      instruction4key.clock.reset();
      instruction4key.start();
    }

    if (instruction4key.status === PsychoJS.Status.STARTED) {
      let theseKeys = instruction4key.getKeys({keyList: ['space'], waitRelease: false});
      _instruction4key_allKeys = _instruction4key_allKeys.concat(theseKeys);
      if (_instruction4key_allKeys.length > 0) {
        instruction4key.keys = _instruction4key_allKeys[_instruction4key_allKeys.length - 1].name;  // just the last key pressed
        instruction4key.rt = _instruction4key_allKeys[_instruction4key_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instruct4Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct4RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct4' ---
    instruct4Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    instruction4key.stop();
    // the Routine "instruct4" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block4key_allKeys;
var block4Components;
function block4RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block4' ---
    t = 0;
    block4Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block4image.setImage(pic4);
    block4key.keys = undefined;
    block4key.rt = undefined;
    _block4key_allKeys = [];
    // keep track of which components have finished
    block4Components = [];
    block4Components.push(cortex_rec);
    block4Components.push(block4image);
    block4Components.push(block4key);
    block4Components.push(eeg_marker);
    
    block4Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function block4RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block4' ---
    // get current time
    t = block4Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block4image* updates
    if (t >= 0.0 && block4image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block4image.tStart = t;  // (not accounting for frame time here)
      block4image.frameNStart = frameN;  // exact frame index
      
      block4image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block4image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block4image.setAutoDraw(false);
    }
    
    // *block4key* updates
    if (t >= 0.0 && block4key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block4key.tStart = t;  // (not accounting for frame time here)
      block4key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block4key.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block4key.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block4key.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block4key.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block4key.status = PsychoJS.Status.FINISHED;
  }

    if (block4key.status === PsychoJS.Status.STARTED) {
      let theseKeys = block4key.getKeys({keyList: ['f', 'j'], waitRelease: false});
      _block4key_allKeys = _block4key_allKeys.concat(theseKeys);
      if (_block4key_allKeys.length > 0) {
        block4key.keys = _block4key_allKeys[_block4key_allKeys.length - 1].name;  // just the last key pressed
        block4key.rt = _block4key_allKeys[_block4key_allKeys.length - 1].rt;
        // was this correct?
        if (block4key.keys == answer4) {
            block4key.corr = 1;
        } else {
            block4key.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // eeg_marker updates
    if (t >= 0.0 && eeg_marker.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      eeg_marker.tStart = t;  // (not accounting for frame time here)
      eeg_marker.frameNStart = frameN;  // exact frame index
      
      psychoJS.window.callOnFlip(function() {
        if (typeof emotiv != "undefined") {
          emotiv.sendMarker('1'.toString(), 'label'.toString(), false)
        }
      });
      eeg_marker.status = PsychoJS.Status.STARTED;
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (eeg_marker.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      eeg_marker.status = PsychoJS.Status.FINISHED;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    block4Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block4RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block4' ---
    block4Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (block4key.keys === undefined) {
      if (['None','none',undefined].includes(answer4)) {
         block4key.corr = 1;  // correct non-response
      } else {
         block4key.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block4key.corr, level);
    }
    psychoJS.experiment.addData('block4key.keys', block4key.keys);
    psychoJS.experiment.addData('block4key.corr', block4key.corr);
    if (typeof block4key.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block4key.rt', block4key.rt);
        routineTimer.reset();
        }
    
    block4key.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _instruction5key_allKeys;
var instruct5Components;
function instruct5RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct5' ---
    t = 0;
    instruct5Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instruction5key.keys = undefined;
    instruction5key.rt = undefined;
    _instruction5key_allKeys = [];
    // keep track of which components have finished
    instruct5Components = [];
    instruct5Components.push(instruction5image);
    instruct5Components.push(instruction5key);
    
    instruct5Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function instruct5RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct5' ---
    // get current time
    t = instruct5Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction5image* updates
    if (t >= 0.0 && instruction5image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction5image.tStart = t;  // (not accounting for frame time here)
      instruction5image.frameNStart = frameN;  // exact frame index
      
      instruction5image.setAutoDraw(true);
    }

    
    // *instruction5key* updates
    if (t >= 0.0 && instruction5key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction5key.tStart = t;  // (not accounting for frame time here)
      instruction5key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      instruction5key.clock.reset();
      instruction5key.start();
    }

    if (instruction5key.status === PsychoJS.Status.STARTED) {
      let theseKeys = instruction5key.getKeys({keyList: ['space'], waitRelease: false});
      _instruction5key_allKeys = _instruction5key_allKeys.concat(theseKeys);
      if (_instruction5key_allKeys.length > 0) {
        instruction5key.keys = _instruction5key_allKeys[_instruction5key_allKeys.length - 1].name;  // just the last key pressed
        instruction5key.rt = _instruction5key_allKeys[_instruction5key_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instruct5Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct5RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct5' ---
    instruct5Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    instruction5key.stop();
    // the Routine "instruct5" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block5key_allKeys;
var block5Components;
function block5RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block5' ---
    t = 0;
    block5Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block5image.setImage(pic5);
    block5key.keys = undefined;
    block5key.rt = undefined;
    _block5key_allKeys = [];
    // keep track of which components have finished
    block5Components = [];
    block5Components.push(cortex_rec_2);
    block5Components.push(block5image);
    block5Components.push(block5key);
    block5Components.push(eeg_marker_2);
    
    block5Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function block5RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block5' ---
    // get current time
    t = block5Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block5image* updates
    if (t >= 0.0 && block5image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block5image.tStart = t;  // (not accounting for frame time here)
      block5image.frameNStart = frameN;  // exact frame index
      
      block5image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block5image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block5image.setAutoDraw(false);
    }
    
    // *block5key* updates
    if (t >= 0.0 && block5key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block5key.tStart = t;  // (not accounting for frame time here)
      block5key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block5key.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block5key.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block5key.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block5key.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block5key.status = PsychoJS.Status.FINISHED;
  }

    if (block5key.status === PsychoJS.Status.STARTED) {
      let theseKeys = block5key.getKeys({keyList: ['f', 'j'], waitRelease: false});
      _block5key_allKeys = _block5key_allKeys.concat(theseKeys);
      if (_block5key_allKeys.length > 0) {
        block5key.keys = _block5key_allKeys[_block5key_allKeys.length - 1].name;  // just the last key pressed
        block5key.rt = _block5key_allKeys[_block5key_allKeys.length - 1].rt;
        // was this correct?
        if (block5key.keys == answer5) {
            block5key.corr = 1;
        } else {
            block5key.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // eeg_marker_2 updates
    if (t >= 0.0 && eeg_marker_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      eeg_marker_2.tStart = t;  // (not accounting for frame time here)
      eeg_marker_2.frameNStart = frameN;  // exact frame index
      
      psychoJS.window.callOnFlip(function() {
        if (typeof emotiv != "undefined") {
          emotiv.sendMarker('1'.toString(), 'label'.toString(), false)
        }
      });
      eeg_marker_2.status = PsychoJS.Status.STARTED;
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (eeg_marker_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      eeg_marker_2.status = PsychoJS.Status.FINISHED;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    block5Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block5RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block5' ---
    block5Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (block5key.keys === undefined) {
      if (['None','none',undefined].includes(answer5)) {
         block5key.corr = 1;  // correct non-response
      } else {
         block5key.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block5key.corr, level);
    }
    psychoJS.experiment.addData('block5key.keys', block5key.keys);
    psychoJS.experiment.addData('block5key.corr', block5key.corr);
    if (typeof block5key.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block5key.rt', block5key.rt);
        routineTimer.reset();
        }
    
    block5key.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _instruction6key_allKeys;
var instruct6Components;
function instruct6RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct6' ---
    t = 0;
    instruct6Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instruction6key.keys = undefined;
    instruction6key.rt = undefined;
    _instruction6key_allKeys = [];
    // keep track of which components have finished
    instruct6Components = [];
    instruct6Components.push(instruction6image);
    instruct6Components.push(instruction6key);
    
    instruct6Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function instruct6RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct6' ---
    // get current time
    t = instruct6Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction6image* updates
    if (t >= 0.0 && instruction6image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction6image.tStart = t;  // (not accounting for frame time here)
      instruction6image.frameNStart = frameN;  // exact frame index
      
      instruction6image.setAutoDraw(true);
    }

    
    // *instruction6key* updates
    if (t >= 0.0 && instruction6key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction6key.tStart = t;  // (not accounting for frame time here)
      instruction6key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      instruction6key.clock.reset();
      instruction6key.start();
    }

    if (instruction6key.status === PsychoJS.Status.STARTED) {
      let theseKeys = instruction6key.getKeys({keyList: ['space'], waitRelease: false});
      _instruction6key_allKeys = _instruction6key_allKeys.concat(theseKeys);
      if (_instruction6key_allKeys.length > 0) {
        instruction6key.keys = _instruction6key_allKeys[_instruction6key_allKeys.length - 1].name;  // just the last key pressed
        instruction6key.rt = _instruction6key_allKeys[_instruction6key_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    instruct6Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct6RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct6' ---
    instruct6Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    instruction6key.stop();
    // the Routine "instruct6" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block6key_allKeys;
var block6Components;
function block6RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block6' ---
    t = 0;
    block6Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block6image.setImage(pic6);
    block6key.keys = undefined;
    block6key.rt = undefined;
    _block6key_allKeys = [];
    // keep track of which components have finished
    block6Components = [];
    block6Components.push(cortex_rec_3);
    block6Components.push(block6image);
    block6Components.push(block6key);
    block6Components.push(eeg_marker_3);
    
    block6Components.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function block6RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block6' ---
    // get current time
    t = block6Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block6image* updates
    if (t >= 0.0 && block6image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block6image.tStart = t;  // (not accounting for frame time here)
      block6image.frameNStart = frameN;  // exact frame index
      
      block6image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block6image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block6image.setAutoDraw(false);
    }
    
    // *block6key* updates
    if (t >= 0.0 && block6key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block6key.tStart = t;  // (not accounting for frame time here)
      block6key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block6key.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block6key.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block6key.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block6key.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block6key.status = PsychoJS.Status.FINISHED;
  }

    if (block6key.status === PsychoJS.Status.STARTED) {
      let theseKeys = block6key.getKeys({keyList: ['f', 'j'], waitRelease: false});
      _block6key_allKeys = _block6key_allKeys.concat(theseKeys);
      if (_block6key_allKeys.length > 0) {
        block6key.keys = _block6key_allKeys[_block6key_allKeys.length - 1].name;  // just the last key pressed
        block6key.rt = _block6key_allKeys[_block6key_allKeys.length - 1].rt;
        // was this correct?
        if (block6key.keys == answer6) {
            block6key.corr = 1;
        } else {
            block6key.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // eeg_marker_3 updates
    if (t >= 0.0 && eeg_marker_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      eeg_marker_3.tStart = t;  // (not accounting for frame time here)
      eeg_marker_3.frameNStart = frameN;  // exact frame index
      
      psychoJS.window.callOnFlip(function() {
        if (typeof emotiv != "undefined") {
          emotiv.sendMarker('1'.toString(), 'label'.toString(), false)
        }
      });
      eeg_marker_3.status = PsychoJS.Status.STARTED;
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (eeg_marker_3.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      eeg_marker_3.status = PsychoJS.Status.FINISHED;
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    block6Components.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block6RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block6' ---
    block6Components.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    // was no response the correct answer?!
    if (block6key.keys === undefined) {
      if (['None','none',undefined].includes(answer6)) {
         block6key.corr = 1;  // correct non-response
      } else {
         block6key.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block6key.corr, level);
    }
    psychoJS.experiment.addData('block6key.keys', block6key.keys);
    psychoJS.experiment.addData('block6key.corr', block6key.corr);
    if (typeof block6key.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block6key.rt', block6key.rt);
        routineTimer.reset();
        }
    
    block6key.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _quitkey_allKeys;
var ENDComponents;
function ENDRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'END' ---
    t = 0;
    ENDClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    quitkey.keys = undefined;
    quitkey.rt = undefined;
    _quitkey_allKeys = [];
    // keep track of which components have finished
    ENDComponents = [];
    ENDComponents.push(quit);
    ENDComponents.push(quitkey);
    
    ENDComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
       });
    return Scheduler.Event.NEXT;
  }
}


function ENDRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'END' ---
    // get current time
    t = ENDClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *quit* updates
    if (t >= 0.0 && quit.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quit.tStart = t;  // (not accounting for frame time here)
      quit.frameNStart = frameN;  // exact frame index
      
      quit.setAutoDraw(true);
    }

    
    // *quitkey* updates
    if (t >= 0.0 && quitkey.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      quitkey.tStart = t;  // (not accounting for frame time here)
      quitkey.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      quitkey.clock.reset();
      quitkey.start();
    }

    if (quitkey.status === PsychoJS.Status.STARTED) {
      let theseKeys = quitkey.getKeys({keyList: ['space'], waitRelease: false});
      _quitkey_allKeys = _quitkey_allKeys.concat(theseKeys);
      if (_quitkey_allKeys.length > 0) {
        quitkey.keys = _quitkey_allKeys[_quitkey_allKeys.length - 1].name;  // just the last key pressed
        quitkey.rt = _quitkey_allKeys[_quitkey_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    ENDComponents.forEach( function(thisComponent) {
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
      }
    });
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ENDRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'END' ---
    ENDComponents.forEach( function(thisComponent) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    });
    quitkey.stop();
    // the Routine "END" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  if (typeof emotiv != "undefined") {
    if (typeof emotiv.end_experiment != "undefined") {
      emotiv.end_experiment();
    }
  }
  
  
  if (typeof emotiv != "undefined") {
    if (typeof emotiv.end_experiment != "undefined") {
      emotiv.end_experiment();
    }
  }
  
  
  if (typeof emotiv != "undefined") {
    if (typeof emotiv.end_experiment != "undefined") {
      emotiv.end_experiment();
    }
  }
  
  
  if (typeof emotiv != "undefined") {
    if (typeof emotiv.end_experiment != "undefined") {
      emotiv.end_experiment();
    }
  }
  
  
  if (typeof emotiv != "undefined") {
    if (typeof emotiv.end_experiment != "undefined") {
      emotiv.end_experiment();
    }
  }
  
  
  if (typeof emotiv != "undefined") {
    if (typeof emotiv.end_experiment != "undefined") {
      emotiv.end_experiment();
    }
  }
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
