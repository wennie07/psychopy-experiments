﻿/*************** 
 * Stroop Test *
 ***************/

import { core, data, sound, util, visual, hardware } from './lib/psychojs-2022.2.5.js';
const { PsychoJS } = core;
const { TrialHandler, MultiStairHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'stroop';  // from the Builder filename that created this script
let expInfo = {
    'participant': `${util.pad(Number.parseFloat(util.randint(0, 999999)).toFixed(0), 6)}`,
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([1.0, 1.0, 1.0]),
  units: 'height',
  waitBlanking: true
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(instruct1RoutineBegin());
flowScheduler.add(instruct1RoutineEachFrame());
flowScheduler.add(instruct1RoutineEnd());
const stroop1LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(stroop1LoopBegin(stroop1LoopScheduler));
flowScheduler.add(stroop1LoopScheduler);
flowScheduler.add(stroop1LoopEnd);
flowScheduler.add(instruct2RoutineBegin());
flowScheduler.add(instruct2RoutineEachFrame());
flowScheduler.add(instruct2RoutineEnd());
const stroop2LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(stroop2LoopBegin(stroop2LoopScheduler));
flowScheduler.add(stroop2LoopScheduler);
flowScheduler.add(stroop2LoopEnd);
flowScheduler.add(instruct3RoutineBegin());
flowScheduler.add(instruct3RoutineEachFrame());
flowScheduler.add(instruct3RoutineEnd());
const stroop3LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(stroop3LoopBegin(stroop3LoopScheduler));
flowScheduler.add(stroop3LoopScheduler);
flowScheduler.add(stroop3LoopEnd);
flowScheduler.add(ENDRoutineBegin());
flowScheduler.add(ENDRoutineEachFrame());
flowScheduler.add(ENDRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    {'name': '完成啦.bmp', 'path': '完成啦.bmp'},
    {'name': 'sheepday.bmp', 'path': 'sheepday.bmp'},
    {'name': '第三轮.bmp', 'path': '第三轮.bmp'},
    {'name': 'block1-loop.xlsx', 'path': 'block1-loop.xlsx'},
    {'name': 'block2-loop.xlsx', 'path': 'block2-loop.xlsx'},
    {'name': '第一轮.bmp', 'path': '第一轮.bmp'},
    {'name': '第二轮.bmp', 'path': '第二轮.bmp'},
    {'name': 'day.bmp', 'path': 'day.bmp'},
    {'name': 'sheepnight.bmp', 'path': 'sheepnight.bmp'},
    {'name': 'night.bmp', 'path': 'night.bmp'},
    {'name': 'block3-loop.xlsx', 'path': 'block3-loop.xlsx'},
    {'name': 'wolfnight.bmp', 'path': 'wolfnight.bmp'},
    {'name': 'wolfday.bmp', 'path': 'wolfday.bmp'}
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2022.2.5';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  

  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);


  return Scheduler.Event.NEXT;
}


var instruct1Clock;
var instruction1;
var start;
var 注视点Clock;
var see;
var block1Clock;
var block1image;
var block1key;
var instruct2Clock;
var instruction2;
var key_resp_3;
var block2Clock;
var block2image;
var block2key;
var instruct3Clock;
var instruction3;
var key_resp_5;
var block3Clock;
var block3image;
var block3key;
var ENDClock;
var endimage;
var endkey;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "instruct1"
  instruct1Clock = new util.Clock();
  instruction1 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction1', units : undefined, 
    image : '第一轮.bmp', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1.0, 1.0, 1.0]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  start = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "注视点"
  注视点Clock = new util.Clock();
  see = new visual.TextStim({
    win: psychoJS.window,
    name: 'see',
    text: '+',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "block1"
  block1Clock = new util.Clock();
  block1image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block1image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  block1key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "instruct2"
  instruct2Clock = new util.Clock();
  instruction2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction2', units : undefined, 
    image : '第二轮.bmp', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  key_resp_3 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "block2"
  block2Clock = new util.Clock();
  block2image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block2image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  block2key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "instruct3"
  instruct3Clock = new util.Clock();
  instruction3 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instruction3', units : undefined, 
    image : '第三轮.bmp', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  key_resp_5 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "block3"
  block3Clock = new util.Clock();
  block3image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'block3image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  block3key = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "END"
  ENDClock = new util.Clock();
  endimage = new visual.ImageStim({
    win : psychoJS.window,
    name : 'endimage', units : undefined, 
    image : '完成啦.bmp', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  endkey = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var _start_allKeys;
var instruct1Components;
function instruct1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct1' ---
    t = 0;
    instruct1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    start.keys = undefined;
    start.rt = undefined;
    _start_allKeys = [];
    // keep track of which components have finished
    instruct1Components = [];
    instruct1Components.push(instruction1);
    instruct1Components.push(start);
    
    for (const thisComponent of instruct1Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function instruct1RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct1' ---
    // get current time
    t = instruct1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction1* updates
    if (t >= 0.0 && instruction1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction1.tStart = t;  // (not accounting for frame time here)
      instruction1.frameNStart = frameN;  // exact frame index
      
      instruction1.setAutoDraw(true);
    }

    
    // *start* updates
    if (t >= 0.0 && start.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      start.tStart = t;  // (not accounting for frame time here)
      start.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { start.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { start.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { start.clearEvents(); });
    }

    if (start.status === PsychoJS.Status.STARTED) {
      let theseKeys = start.getKeys({keyList: ['space'], waitRelease: false});
      _start_allKeys = _start_allKeys.concat(theseKeys);
      if (_start_allKeys.length > 0) {
        start.keys = _start_allKeys[_start_allKeys.length - 1].name;  // just the last key pressed
        start.rt = _start_allKeys[_start_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instruct1Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct1' ---
    for (const thisComponent of instruct1Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    start.stop();
    // the Routine "instruct1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var stroop1;
function stroop1LoopBegin(stroop1LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    stroop1 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 8, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block1-loop.xlsx',
      seed: undefined, name: 'stroop1'
    });
    psychoJS.experiment.addLoop(stroop1); // add the loop to the experiment
    currentLoop = stroop1;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisStroop1 of stroop1) {
      snapshot = stroop1.getSnapshot();
      stroop1LoopScheduler.add(importConditions(snapshot));
      stroop1LoopScheduler.add(注视点RoutineBegin(snapshot));
      stroop1LoopScheduler.add(注视点RoutineEachFrame());
      stroop1LoopScheduler.add(注视点RoutineEnd(snapshot));
      stroop1LoopScheduler.add(block1RoutineBegin(snapshot));
      stroop1LoopScheduler.add(block1RoutineEachFrame());
      stroop1LoopScheduler.add(block1RoutineEnd(snapshot));
      stroop1LoopScheduler.add(stroop1LoopEndIteration(stroop1LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function stroop1LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(stroop1);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function stroop1LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var stroop2;
function stroop2LoopBegin(stroop2LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    stroop2 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 8, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block2-loop.xlsx',
      seed: undefined, name: 'stroop2'
    });
    psychoJS.experiment.addLoop(stroop2); // add the loop to the experiment
    currentLoop = stroop2;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisStroop2 of stroop2) {
      snapshot = stroop2.getSnapshot();
      stroop2LoopScheduler.add(importConditions(snapshot));
      stroop2LoopScheduler.add(注视点RoutineBegin(snapshot));
      stroop2LoopScheduler.add(注视点RoutineEachFrame());
      stroop2LoopScheduler.add(注视点RoutineEnd(snapshot));
      stroop2LoopScheduler.add(block2RoutineBegin(snapshot));
      stroop2LoopScheduler.add(block2RoutineEachFrame());
      stroop2LoopScheduler.add(block2RoutineEnd(snapshot));
      stroop2LoopScheduler.add(stroop2LoopEndIteration(stroop2LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function stroop2LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(stroop2);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function stroop2LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var stroop3;
function stroop3LoopBegin(stroop3LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    stroop3 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 7, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'block3-loop.xlsx',
      seed: undefined, name: 'stroop3'
    });
    psychoJS.experiment.addLoop(stroop3); // add the loop to the experiment
    currentLoop = stroop3;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisStroop3 of stroop3) {
      snapshot = stroop3.getSnapshot();
      stroop3LoopScheduler.add(importConditions(snapshot));
      stroop3LoopScheduler.add(注视点RoutineBegin(snapshot));
      stroop3LoopScheduler.add(注视点RoutineEachFrame());
      stroop3LoopScheduler.add(注视点RoutineEnd(snapshot));
      stroop3LoopScheduler.add(block3RoutineBegin(snapshot));
      stroop3LoopScheduler.add(block3RoutineEachFrame());
      stroop3LoopScheduler.add(block3RoutineEnd(snapshot));
      stroop3LoopScheduler.add(stroop3LoopEndIteration(stroop3LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function stroop3LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(stroop3);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function stroop3LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var 注视点Components;
function 注视点RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine '注视点' ---
    t = 0;
    注视点Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(0.600000);
    // update component parameters for each repeat
    // keep track of which components have finished
    注视点Components = [];
    注视点Components.push(see);
    
    for (const thisComponent of 注视点Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function 注视点RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine '注视点' ---
    // get current time
    t = 注视点Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *see* updates
    if (t >= 0.0 && see.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      see.tStart = t;  // (not accounting for frame time here)
      see.frameNStart = frameN;  // exact frame index
      
      see.setAutoDraw(true);
    }

    frameRemains = 0.0 + 0.6 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (see.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      see.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of 注视点Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function 注视点RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine '注视点' ---
    for (const thisComponent of 注视点Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block1key_allKeys;
var block1Components;
function block1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block1' ---
    t = 0;
    block1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block1image.setImage(pic);
    block1key.keys = undefined;
    block1key.rt = undefined;
    _block1key_allKeys = [];
    // keep track of which components have finished
    block1Components = [];
    block1Components.push(block1image);
    block1Components.push(block1key);
    
    for (const thisComponent of block1Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function block1RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block1' ---
    // get current time
    t = block1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block1image* updates
    if (t >= 0.0 && block1image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block1image.tStart = t;  // (not accounting for frame time here)
      block1image.frameNStart = frameN;  // exact frame index
      
      block1image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block1image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block1image.setAutoDraw(false);
    }
    
    // *block1key* updates
    if (t >= 0.0 && block1key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block1key.tStart = t;  // (not accounting for frame time here)
      block1key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block1key.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block1key.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block1key.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block1key.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block1key.status = PsychoJS.Status.FINISHED;
  }

    if (block1key.status === PsychoJS.Status.STARTED) {
      let theseKeys = block1key.getKeys({keyList: ['f', 'j'], waitRelease: false});
      _block1key_allKeys = _block1key_allKeys.concat(theseKeys);
      if (_block1key_allKeys.length > 0) {
        block1key.keys = _block1key_allKeys[_block1key_allKeys.length - 1].name;  // just the last key pressed
        block1key.rt = _block1key_allKeys[_block1key_allKeys.length - 1].rt;
        // was this correct?
        if (block1key.keys == answer) {
            block1key.corr = 1;
        } else {
            block1key.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of block1Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block1' ---
    for (const thisComponent of block1Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // was no response the correct answer?!
    if (block1key.keys === undefined) {
      if (['None','none',undefined].includes(answer)) {
         block1key.corr = 1;  // correct non-response
      } else {
         block1key.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block1key.corr, level);
    }
    psychoJS.experiment.addData('block1key.keys', block1key.keys);
    psychoJS.experiment.addData('block1key.corr', block1key.corr);
    if (typeof block1key.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block1key.rt', block1key.rt);
        routineTimer.reset();
        }
    
    block1key.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _key_resp_3_allKeys;
var instruct2Components;
function instruct2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct2' ---
    t = 0;
    instruct2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_3.keys = undefined;
    key_resp_3.rt = undefined;
    _key_resp_3_allKeys = [];
    // keep track of which components have finished
    instruct2Components = [];
    instruct2Components.push(instruction2);
    instruct2Components.push(key_resp_3);
    
    for (const thisComponent of instruct2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function instruct2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct2' ---
    // get current time
    t = instruct2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction2* updates
    if (t >= 0.0 && instruction2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction2.tStart = t;  // (not accounting for frame time here)
      instruction2.frameNStart = frameN;  // exact frame index
      
      instruction2.setAutoDraw(true);
    }

    
    // *key_resp_3* updates
    if (t >= 0.0 && key_resp_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_3.tStart = t;  // (not accounting for frame time here)
      key_resp_3.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_3.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_3.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_3.clearEvents(); });
    }

    if (key_resp_3.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_3.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_3_allKeys = _key_resp_3_allKeys.concat(theseKeys);
      if (_key_resp_3_allKeys.length > 0) {
        key_resp_3.keys = _key_resp_3_allKeys[_key_resp_3_allKeys.length - 1].name;  // just the last key pressed
        key_resp_3.rt = _key_resp_3_allKeys[_key_resp_3_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instruct2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct2' ---
    for (const thisComponent of instruct2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    key_resp_3.stop();
    // the Routine "instruct2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block2key_allKeys;
var block2Components;
function block2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block2' ---
    t = 0;
    block2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block2image.setImage(pic2);
    block2key.keys = undefined;
    block2key.rt = undefined;
    _block2key_allKeys = [];
    // keep track of which components have finished
    block2Components = [];
    block2Components.push(block2image);
    block2Components.push(block2key);
    
    for (const thisComponent of block2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function block2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block2' ---
    // get current time
    t = block2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block2image* updates
    if (t >= 0.0 && block2image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block2image.tStart = t;  // (not accounting for frame time here)
      block2image.frameNStart = frameN;  // exact frame index
      
      block2image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block2image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block2image.setAutoDraw(false);
    }
    
    // *block2key* updates
    if (t >= 0.0 && block2key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block2key.tStart = t;  // (not accounting for frame time here)
      block2key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block2key.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block2key.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block2key.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block2key.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block2key.status = PsychoJS.Status.FINISHED;
  }

    if (block2key.status === PsychoJS.Status.STARTED) {
      let theseKeys = block2key.getKeys({keyList: ['f', 'j'], waitRelease: false});
      _block2key_allKeys = _block2key_allKeys.concat(theseKeys);
      if (_block2key_allKeys.length > 0) {
        block2key.keys = _block2key_allKeys[_block2key_allKeys.length - 1].name;  // just the last key pressed
        block2key.rt = _block2key_allKeys[_block2key_allKeys.length - 1].rt;
        // was this correct?
        if (block2key.keys == answer2) {
            block2key.corr = 1;
        } else {
            block2key.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of block2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block2' ---
    for (const thisComponent of block2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // was no response the correct answer?!
    if (block2key.keys === undefined) {
      if (['None','none',undefined].includes(answer2)) {
         block2key.corr = 1;  // correct non-response
      } else {
         block2key.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block2key.corr, level);
    }
    psychoJS.experiment.addData('block2key.keys', block2key.keys);
    psychoJS.experiment.addData('block2key.corr', block2key.corr);
    if (typeof block2key.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block2key.rt', block2key.rt);
        routineTimer.reset();
        }
    
    block2key.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _key_resp_5_allKeys;
var instruct3Components;
function instruct3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instruct3' ---
    t = 0;
    instruct3Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_5.keys = undefined;
    key_resp_5.rt = undefined;
    _key_resp_5_allKeys = [];
    // keep track of which components have finished
    instruct3Components = [];
    instruct3Components.push(instruction3);
    instruct3Components.push(key_resp_5);
    
    for (const thisComponent of instruct3Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function instruct3RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instruct3' ---
    // get current time
    t = instruct3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instruction3* updates
    if (t >= 0.0 && instruction3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instruction3.tStart = t;  // (not accounting for frame time here)
      instruction3.frameNStart = frameN;  // exact frame index
      
      instruction3.setAutoDraw(true);
    }

    
    // *key_resp_5* updates
    if (t >= 0.0 && key_resp_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_5.tStart = t;  // (not accounting for frame time here)
      key_resp_5.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_5.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_5.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_5.clearEvents(); });
    }

    if (key_resp_5.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_5.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_5_allKeys = _key_resp_5_allKeys.concat(theseKeys);
      if (_key_resp_5_allKeys.length > 0) {
        key_resp_5.keys = _key_resp_5_allKeys[_key_resp_5_allKeys.length - 1].name;  // just the last key pressed
        key_resp_5.rt = _key_resp_5_allKeys[_key_resp_5_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instruct3Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instruct3RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instruct3' ---
    for (const thisComponent of instruct3Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    key_resp_5.stop();
    // the Routine "instruct3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _block3key_allKeys;
var block3Components;
function block3RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'block3' ---
    t = 0;
    block3Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.700000);
    // update component parameters for each repeat
    block3image.setImage(pic3);
    block3key.keys = undefined;
    block3key.rt = undefined;
    _block3key_allKeys = [];
    // keep track of which components have finished
    block3Components = [];
    block3Components.push(block3image);
    block3Components.push(block3key);
    
    for (const thisComponent of block3Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function block3RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'block3' ---
    // get current time
    t = block3Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *block3image* updates
    if (t >= 0.0 && block3image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block3image.tStart = t;  // (not accounting for frame time here)
      block3image.frameNStart = frameN;  // exact frame index
      
      block3image.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block3image.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block3image.setAutoDraw(false);
    }
    
    // *block3key* updates
    if (t >= 0.0 && block3key.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      block3key.tStart = t;  // (not accounting for frame time here)
      block3key.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { block3key.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { block3key.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { block3key.clearEvents(); });
    }

    frameRemains = 0.0 + 1.7 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (block3key.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      block3key.status = PsychoJS.Status.FINISHED;
  }

    if (block3key.status === PsychoJS.Status.STARTED) {
      let theseKeys = block3key.getKeys({keyList: ['f', 'j', 'space'], waitRelease: false});
      _block3key_allKeys = _block3key_allKeys.concat(theseKeys);
      if (_block3key_allKeys.length > 0) {
        block3key.keys = _block3key_allKeys[_block3key_allKeys.length - 1].name;  // just the last key pressed
        block3key.rt = _block3key_allKeys[_block3key_allKeys.length - 1].rt;
        // was this correct?
        if (block3key.keys == answer3) {
            block3key.corr = 1;
        } else {
            block3key.corr = 0;
        }
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of block3Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function block3RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'block3' ---
    for (const thisComponent of block3Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // was no response the correct answer?!
    if (block3key.keys === undefined) {
      if (['None','none',undefined].includes(answer3)) {
         block3key.corr = 1;  // correct non-response
      } else {
         block3key.corr = 0;  // failed to respond (incorrectly)
      }
    }
    // store data for current loop
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(block3key.corr, level);
    }
    psychoJS.experiment.addData('block3key.keys', block3key.keys);
    psychoJS.experiment.addData('block3key.corr', block3key.corr);
    if (typeof block3key.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('block3key.rt', block3key.rt);
        routineTimer.reset();
        }
    
    block3key.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _endkey_allKeys;
var ENDComponents;
function ENDRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'END' ---
    t = 0;
    ENDClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    endkey.keys = undefined;
    endkey.rt = undefined;
    _endkey_allKeys = [];
    // keep track of which components have finished
    ENDComponents = [];
    ENDComponents.push(endimage);
    ENDComponents.push(endkey);
    
    for (const thisComponent of ENDComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function ENDRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'END' ---
    // get current time
    t = ENDClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *endimage* updates
    if (t >= 0.0 && endimage.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      endimage.tStart = t;  // (not accounting for frame time here)
      endimage.frameNStart = frameN;  // exact frame index
      
      endimage.setAutoDraw(true);
    }

    
    // *endkey* updates
    if (t >= 0.0 && endkey.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      endkey.tStart = t;  // (not accounting for frame time here)
      endkey.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      endkey.clock.reset();
      endkey.start();
    }

    if (endkey.status === PsychoJS.Status.STARTED) {
      let theseKeys = endkey.getKeys({keyList: ['space'], waitRelease: false});
      _endkey_allKeys = _endkey_allKeys.concat(theseKeys);
      if (_endkey_allKeys.length > 0) {
        endkey.keys = _endkey_allKeys[_endkey_allKeys.length - 1].name;  // just the last key pressed
        endkey.rt = _endkey_allKeys[_endkey_allKeys.length - 1].rt;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of ENDComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function ENDRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'END' ---
    for (const thisComponent of ENDComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    endkey.stop();
    // the Routine "END" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
